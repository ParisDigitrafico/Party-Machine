-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.5.20 - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando estructura para tabla tramitem_dev.acc_app
DROP TABLE IF EXISTS `acc_app`;
CREATE TABLE IF NOT EXISTS `acc_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` char(155) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_app: ~2 rows (aproximadamente)
DELETE FROM `acc_app`;
/*!40000 ALTER TABLE `acc_app` DISABLE KEYS */;
INSERT INTO `acc_app` (`id`, `nombre`) VALUES
	(1, 'Sistema'),
	(2, 'Clientes');
/*!40000 ALTER TABLE `acc_app` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_configuracion
DROP TABLE IF EXISTS `acc_configuracion`;
CREATE TABLE IF NOT EXISTS `acc_configuracion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` char(155) DEFAULT NULL,
  `valor` text,
  `tipo` enum('INT','CHAR','BOOL','DECIMAL','ENUM') DEFAULT NULL,
  `opcion` char(155) DEFAULT NULL,
  `descripcion` char(155) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla tramitem_dev.acc_configuracion: ~3 rows (aproximadamente)
DELETE FROM `acc_configuracion`;
/*!40000 ALTER TABLE `acc_configuracion` DISABLE KEYS */;
INSERT INTO `acc_configuracion` (`id`, `clave`, `valor`, `tipo`, `opcion`, `descripcion`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'MAX_INTENTOS_PASS', '5', 'INT', '', 'El número maximo de intentos fallidos antes de bloquear usuario.', '0000-00-00 00:00:00', NULL, NULL),
	(2, 'IMPRIMIR_VENTA_FORMATO_TICKET', 'true', 'BOOL', '', 'Las ventas se imprimiran en formato de ticket', '2022-04-11 09:37:45', '2022-04-12 12:13:19', NULL),
	(3, 'PORCENTAJE_COMISION_CONEKTA', '10', 'INT', '', 'El porcentaje en número entero que cobrara conekta', '0000-00-00 00:00:00', NULL, NULL);
/*!40000 ALTER TABLE `acc_configuracion` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_confirmar_cuenta
DROP TABLE IF EXISTS `acc_confirmar_cuenta`;
CREATE TABLE IF NOT EXISTS `acc_confirmar_cuenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL DEFAULT '0',
  `tipo` enum('USUARIO','CLIENTE') DEFAULT 'USUARIO',
  `ckey` char(255) DEFAULT NULL,
  `email` char(255) DEFAULT NULL,
  `name` char(255) DEFAULT NULL,
  `lastname` char(255) DEFAULT NULL,
  `phone` char(10) DEFAULT NULL,
  `pswd` char(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ckey` (`ckey`) USING BTREE,
  KEY `tipo` (`tipo`) USING BTREE,
  KEY `idusuario` (`usuario_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla tramitem_dev.acc_confirmar_cuenta: ~0 rows (aproximadamente)
DELETE FROM `acc_confirmar_cuenta`;
/*!40000 ALTER TABLE `acc_confirmar_cuenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `acc_confirmar_cuenta` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_control_sesion
DROP TABLE IF EXISTS `acc_control_sesion`;
CREATE TABLE IF NOT EXISTS `acc_control_sesion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `app` char(155) NOT NULL DEFAULT '',
  `medio` enum('MOVIL','WEB','APP_ANDROID','APP_IOS','OTRO') NOT NULL DEFAULT 'WEB',
  `dispositivo_fp` char(155) DEFAULT NULL,
  `token` char(155) DEFAULT NULL,
  `direccion_ip` char(155) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idusuario` (`usuario_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_control_sesion: ~4 rows (aproximadamente)
DELETE FROM `acc_control_sesion`;
/*!40000 ALTER TABLE `acc_control_sesion` DISABLE KEYS */;
INSERT INTO `acc_control_sesion` (`id`, `usuario_id`, `app`, `medio`, `dispositivo_fp`, `token`, `direccion_ip`, `created_at`) VALUES
	(3, 1001, 'sistema', 'WEB', '68b2780b1973dae58db41b6ee777aa1fe8a87a4c', NULL, NULL, '2022-11-25 18:25:02'),
	(4, 1001, 'sistema', 'WEB', '8829ef59d49e591cc1f6085a8f824448d50e3291', NULL, NULL, '2022-11-26 09:54:02'),
	(7, 1001, 'sistema', 'WEB', '93055bdf83c56afe099fb2a77a9c437c4073557c', NULL, NULL, '2022-11-30 17:48:31'),
	(8, 1001, 'sistema', 'WEB', '08b61afb803e1874fb51593c0eb19292e2fa2460', NULL, NULL, '2022-12-02 11:15:30');
/*!40000 ALTER TABLE `acc_control_sesion` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_folio
DROP TABLE IF EXISTS `acc_folio`;
CREATE TABLE IF NOT EXISTS `acc_folio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal_id` int(11) NOT NULL DEFAULT '1',
  `clave` char(155) DEFAULT NULL,
  `serie` char(155) DEFAULT NULL,
  `ultimo_folio` tinyint(4) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `clave` (`clave`) USING BTREE,
  KEY `idsucursal` (`sucursal_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_folio: ~2 rows (aproximadamente)
DELETE FROM `acc_folio`;
/*!40000 ALTER TABLE `acc_folio` DISABLE KEYS */;
INSERT INTO `acc_folio` (`id`, `sucursal_id`, `clave`, `serie`, `ultimo_folio`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 1, 'USUARIO', 'USR', 5, 1, '2022-03-01 22:20:59', '2022-10-26 10:58:44', NULL, 0),
	(2, 1, 'CLIENTE', 'CTE', 2, 1, '2022-03-01 22:20:59', '2022-10-26 10:59:52', NULL, 0);
/*!40000 ALTER TABLE `acc_folio` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_log
DROP TABLE IF EXISTS `acc_log`;
CREATE TABLE IF NOT EXISTS `acc_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` enum('VENTA','RENTA') NOT NULL DEFAULT 'VENTA',
  `accion` char(155) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `modulo` (`clave`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_log: ~1 rows (aproximadamente)
DELETE FROM `acc_log`;
/*!40000 ALTER TABLE `acc_log` DISABLE KEYS */;
INSERT INTO `acc_log` (`id`, `clave`, `accion`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 'VENTA', 'Este usuario cambio la contraseña de cliente <b>demo@gmail.com</b>', 1, '2022-04-12 16:43:10', NULL, NULL, 1001);
/*!40000 ALTER TABLE `acc_log` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_modulo
DROP TABLE IF EXISTS `acc_modulo`;
CREATE TABLE IF NOT EXISTS `acc_modulo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpadre` int(11) NOT NULL DEFAULT '0',
  `app_id` int(11) NOT NULL DEFAULT '1',
  `clave` char(50) DEFAULT NULL,
  `nombre` char(50) DEFAULT NULL,
  `titulo` char(50) DEFAULT NULL,
  `es_menu` tinyint(4) NOT NULL DEFAULT '0',
  `url_menu` char(50) DEFAULT NULL,
  `icon` char(50) DEFAULT NULL,
  `orden` smallint(6) NOT NULL DEFAULT '1',
  `es_publico` tinyint(4) NOT NULL DEFAULT '0',
  `tiene_permisos` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Columna 4` (`clave`) USING BTREE,
  KEY `idpadre` (`idpadre`) USING BTREE,
  KEY `idsistema` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_modulo: ~13 rows (aproximadamente)
DELETE FROM `acc_modulo`;
/*!40000 ALTER TABLE `acc_modulo` DISABLE KEYS */;
INSERT INTO `acc_modulo` (`id`, `idpadre`, `app_id`, `clave`, `nombre`, `titulo`, `es_menu`, `url_menu`, `icon`, `orden`, `es_publico`, `tiene_permisos`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(10, 0, 1, 'HOME', 'Inicio', NULL, 1, '/sistema/home/', 'fas fa-tachometer-alt', 0, 1, 0, 1, '2022-02-17 07:56:36', NULL, NULL, 0),
	(11, 0, 1, 'M_USUARIOS', 'Usuarios', 'Lista Usuarios', 1, '/sistema/usuarios/', 'fas fa-user', 1, 0, 1, 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(12, 0, 1, 'M_CONFIGURACIONES', 'Configuraciones', NULL, 1, '/sistema/configuraciones/', 'fas fa-wrench', 9999, 0, 1, 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(13, 0, 1, 'M_CLIENTES', 'Clientes', 'Lista Clientes', 1, '/sistema/clientes/', 'fas fa-address-book', 2, 0, 1, 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(14, 0, 1, 'MENU_TIPOSVISAS', 'Tipos Visas', NULL, 1, '#', 'fab fa-cc-visa', 9997, 0, 1, 1, '2022-01-17 17:14:19', NULL, NULL, 0),
	(16, 0, 1, 'M_REGISTRO_ACTIVIDAD', 'Registro Actividades', NULL, 1, '/sistema/logs/', 'fas fa-file-alt', 9998, 0, 1, 1, '2022-04-11 01:49:54', NULL, NULL, 0),
	(17, 0, 1, 'M_PEDIDOS', 'Pedidos', 'Lista Pedidos', 1, '/sistema/pedidos/', 'fas fa-shopping-cart', 3, 1, 1, 1, '2022-07-31 13:09:31', NULL, NULL, 0),
	(18, 14, 1, 'M_TIPOSVISAS', 'Listado', 'Lista Tipos Visas', 1, '/sistema/tiposvisas/', NULL, 1, 1, 1, 1, '2022-07-31 13:20:39', NULL, NULL, 0),
	(19, 0, 1, 'MENU_SERVICIOS', 'Servicios', '', 1, '#', 'fas fa-headset', 4, 0, 1, 1, '2022-07-31 13:09:31', NULL, NULL, 0),
	(20, 19, 1, 'M_SERVICIOS', 'Listado', 'Lista Servicios', 1, '/sistema/servicios/', '', 1, 0, 1, 1, '2022-07-31 13:20:39', NULL, NULL, 0),
	(23, 0, 1, 'MENU_SITIOWEB', 'Sitio Web', '', 1, '#', 'fas fa-globe', 5, 0, 1, 1, '2022-07-31 13:20:39', NULL, NULL, 0),
	(24, 23, 1, 'M_PAGINAS', 'Páginas', 'Lista Páginas', 1, '/sistema/paginas/', '', 5, 0, 1, 1, '2022-07-31 13:20:39', NULL, NULL, 0),
	(26, 23, 1, 'M_BANNERS', 'Banners', 'Lista Banners', 1, '/sistema/banners/', '', 5, 0, 1, 1, '2022-07-31 13:20:39', NULL, NULL, 0);
/*!40000 ALTER TABLE `acc_modulo` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_perfil
DROP TABLE IF EXISTS `acc_perfil`;
CREATE TABLE IF NOT EXISTS `acc_perfil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` char(155) DEFAULT NULL,
  `descripcion` char(155) DEFAULT NULL,
  `es_fijo` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_perfil: ~9 rows (aproximadamente)
DELETE FROM `acc_perfil`;
/*!40000 ALTER TABLE `acc_perfil` DISABLE KEYS */;
INSERT INTO `acc_perfil` (`id`, `nombre`, `descripcion`, `es_fijo`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 'Administrador', NULL, 1, 1, '2021-06-20 00:22:18', '2022-10-05 11:12:05', NULL, 0),
	(2, 'Gerente Gral.', NULL, 0, 1, '2021-06-20 00:22:48', '2022-04-02 21:36:02', NULL, 0),
	(3, 'Revisor Brazaletes', NULL, 0, 1, '2021-06-20 00:22:56', '2022-03-31 20:08:59', NULL, 0),
	(5, 'Cliente', NULL, 1, 1, '2021-06-27 12:59:28', '2022-03-31 19:49:11', NULL, 0),
	(6, 'Gerente Ventas', NULL, 0, 1, '2021-06-27 12:59:28', '2022-05-03 17:46:04', NULL, 0),
	(7, 'Vendedor Brazaletes', NULL, 0, 1, '2022-03-31 20:03:23', '2022-05-04 15:12:33', NULL, 0),
	(8, 'Gerente RRHH.', NULL, 0, 1, '2022-03-31 20:06:28', '2022-04-07 18:12:17', NULL, 0),
	(9, 'Recepcionista', NULL, 0, 1, '2022-04-27 02:16:32', '2022-09-12 04:07:36', NULL, 0),
	(10, 'Vendedor Productos', NULL, 0, 1, '2022-05-03 12:44:05', '2022-05-04 15:12:47', NULL, 0);
/*!40000 ALTER TABLE `acc_perfil` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_perfil_permiso
DROP TABLE IF EXISTS `acc_perfil_permiso`;
CREATE TABLE IF NOT EXISTS `acc_perfil_permiso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perfil_id` int(11) NOT NULL,
  `permiso_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_perfil_permiso: ~0 rows (aproximadamente)
DELETE FROM `acc_perfil_permiso`;
/*!40000 ALTER TABLE `acc_perfil_permiso` DISABLE KEYS */;
/*!40000 ALTER TABLE `acc_perfil_permiso` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_permiso
DROP TABLE IF EXISTS `acc_permiso`;
CREATE TABLE IF NOT EXISTS `acc_permiso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo_id` int(11) NOT NULL DEFAULT '0',
  `clave` char(50) DEFAULT NULL,
  `descripcion` char(155) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `clave` (`clave`) USING BTREE,
  KEY `modulo_id` (`modulo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_permiso: ~39 rows (aproximadamente)
DELETE FROM `acc_permiso`;
/*!40000 ALTER TABLE `acc_permiso` DISABLE KEYS */;
INSERT INTO `acc_permiso` (`id`, `modulo_id`, `clave`, `descripcion`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 11, 'C_USUARIO', 'Crear Usuarios', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(2, 11, 'R_USUARIO', 'Ver Usuarios', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(3, 11, 'U_USUARIO', 'Editar usuarios', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(4, 11, 'D_USUARIO', 'Elimina Usuarios', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(5, 12, 'R_CONFIG', 'Ver Configuraciones', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(6, 12, 'U_CONFIG', 'Editar Configuraciones', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(8, 11, 'C_PERFIL', 'Crear perfiles', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(9, 11, 'R_PERFIL', 'Ver perfiles', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(10, 11, 'U_PERFIL', 'Editar perfiles', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(11, 11, 'D_PERFIL', 'Eliminar perfiles', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(12, 13, 'R_CLIENTE', 'Ver Clientes', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(21, 14, 'R_CATALOGO', 'Ver Catálogos', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(22, 13, 'C_CLIENTE', 'Crear Clientes', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(23, 13, 'U_CLIENTE', 'Editar Clientes', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(24, 13, 'D_CLIENTE', 'Eliminar Clientes', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(57, 14, 'C_CATALOGO', 'Crear Registros Catálogos', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(58, 14, 'U_CATALOGO', 'Editar Catálogos', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(59, 14, 'D_CATALOGO', 'Eliminar Datos Catálogos', 1, '0000-00-00 00:00:00', NULL, NULL, 0),
	(68, 16, 'R_LOG', 'Ver Registro Activades', 1, '2022-03-25 22:40:26', NULL, NULL, 0),
	(107, 17, 'R_PEDIDO', 'Ver Pedido', 1, '2022-07-31 13:11:04', NULL, NULL, 0),
	(110, 17, 'C_PEDIDO', 'Crear Pedidos', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(111, 17, 'U_PEDIDO', 'Editar Pedidos', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(112, 17, 'D_PEDIDO', 'Eliminar Pedidos', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(115, 20, 'R_SERVICIO', 'Ver Servicio', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(116, 20, 'C_SERVICIO', 'Crear Servicio', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(118, 20, 'U_SERVICIO', 'Editar Servicio', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(119, 20, 'D_SERVICIO', 'Eliminar Servicio', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(130, 24, 'R_PAGINA', 'Ver Páginas', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(131, 24, 'C_PAGINA', 'Crear Páginas', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(132, 24, 'U_PAGINA', 'Eliminar Páginas', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(133, 24, 'D_PAGINA', 'Editar Páginas', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(139, 26, 'R_BANNER', 'Ver Banners', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(140, 26, 'C_BANNER', 'Crear Banners', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(141, 26, 'U_BANNER', 'Editar Banners', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(142, 26, 'D_BANNER', 'Eliminar Banners', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(143, 18, 'C_TIPOVISA', 'Crear Tipo Visa', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(144, 18, 'R_TIPOVISA', 'Ver Tipo Visa', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(145, 18, 'U_TIPOVISA', 'Editar Tipo Visa', 1, '2022-07-31 13:11:28', NULL, NULL, 0),
	(146, 18, 'D_TIPOVISA', 'Eliminar Tipo Visa', 1, '2022-07-31 13:11:28', NULL, NULL, 0);
/*!40000 ALTER TABLE `acc_permiso` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_usuario
DROP TABLE IF EXISTS `acc_usuario`;
CREATE TABLE IF NOT EXISTS `acc_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serie` char(155) DEFAULT NULL,
  `folio` int(11) DEFAULT NULL,
  `codigo` char(155) DEFAULT NULL,
  `user` char(155) DEFAULT NULL,
  `pass` char(155) DEFAULT NULL,
  `nombre` char(155) DEFAULT NULL,
  `apellidos` char(155) DEFAULT NULL,
  `telefono` char(155) DEFAULT NULL,
  `empresa` char(155) DEFAULT NULL,
  `tiposangre` int(11) DEFAULT NULL,
  `genero` enum('M','F') DEFAULT NULL,
  `es_super` tinyint(4) NOT NULL DEFAULT '0',
  `es_cliente` tinyint(4) NOT NULL DEFAULT '0',
  `es_bloqueado` tinyint(4) NOT NULL DEFAULT '0',
  `intentos_fallidos` int(11) DEFAULT NULL,
  `notificar_actividad` tinyint(4) NOT NULL DEFAULT '0',
  `fecha_nacimiento` date DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `serie` (`serie`) USING BTREE,
  KEY `folio` (`folio`) USING BTREE,
  KEY `clave` (`codigo`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1008 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_usuario: ~7 rows (aproximadamente)
DELETE FROM `acc_usuario`;
/*!40000 ALTER TABLE `acc_usuario` DISABLE KEYS */;
INSERT INTO `acc_usuario` (`id`, `serie`, `folio`, `codigo`, `user`, `pass`, `nombre`, `apellidos`, `telefono`, `empresa`, `tiposangre`, `genero`, `es_super`, `es_cliente`, `es_bloqueado`, `intentos_fallidos`, `notificar_actividad`, `fecha_nacimiento`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1001, 'USR', 1, 'USR000001', 'admin@tramitem.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Administrador', '.', NULL, NULL, NULL, NULL, 1, 0, 0, 0, 1, NULL, 1, '2022-01-12 11:35:07', '2022-12-02 17:47:06', NULL, 0),
	(1002, 'USR', 2, 'USR000002', 'admon@tramitem.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Administración', '.', NULL, NULL, NULL, NULL, 0, 0, 0, NULL, 1, NULL, 1, '2022-01-12 11:35:07', '2022-10-26 10:27:27', NULL, 0),
	(1003, 'USR', 3, 'USR000003', 'macosta@digitrafico.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Macosta', '.', NULL, NULL, NULL, NULL, 1, 0, 0, NULL, 1, NULL, 1, '2022-01-12 11:35:07', '2022-07-26 12:08:29', NULL, 0),
	(1004, 'CTE', 1, 'CTE000001', 'manuel.enrique23@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Manuel Enrique', 'Acosta Ibarra', '999 999 9999', NULL, NULL, 'M', 0, 1, 0, NULL, 0, '1989-05-23', 1, '2022-07-19 11:19:48', '2022-09-23 15:20:31', NULL, 0),
	(1005, 'USR', 4, 'USR000004', 'wertq@gmailo.com', '22ea1c649c82946aa6e479e1ffd321e4a318b1b0', 'qww', 'qe', '999 999 9999', NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, 1, '2022-10-10 15:10:04', '2022-10-26 10:58:09', NULL, 0),
	(1006, 'USR', 5, 'USR000005', 'tretyrey@gamil.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'reyyy', 'yyy', '56 7576 7777', NULL, NULL, NULL, 0, 0, 0, NULL, 0, NULL, 1, '2022-10-26 10:58:44', '2022-10-26 10:58:59', NULL, 0),
	(1007, 'CTE', 2, 'CTE000002', 'jhi@gamis.com', NULL, 'fewrf', 'asdf', '435535335', 'asdf', NULL, 'M', 0, 1, 0, NULL, 0, '2022-10-26', 1, '2022-10-26 10:59:52', '2022-10-26 11:00:48', NULL, 0);
/*!40000 ALTER TABLE `acc_usuario` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.acc_usuario_perfil
DROP TABLE IF EXISTS `acc_usuario_perfil`;
CREATE TABLE IF NOT EXISTS `acc_usuario_perfil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=297 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.acc_usuario_perfil: ~5 rows (aproximadamente)
DELETE FROM `acc_usuario_perfil`;
/*!40000 ALTER TABLE `acc_usuario_perfil` DISABLE KEYS */;
INSERT INTO `acc_usuario_perfil` (`id`, `usuario_id`, `perfil_id`) VALUES
	(283, 1054, 5),
	(291, 1001, 1),
	(292, 1002, 1),
	(295, 1005, 1),
	(296, 1007, 5);
/*!40000 ALTER TABLE `acc_usuario_perfil` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.gen_archivo
DROP TABLE IF EXISTS `gen_archivo`;
CREATE TABLE IF NOT EXISTS `gen_archivo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL DEFAULT '0',
  `banner_id` int(11) NOT NULL DEFAULT '0',
  `clave` char(155) DEFAULT NULL,
  `nombre` char(155) DEFAULT NULL,
  `nombre_en` char(155) DEFAULT NULL,
  `descripcion` char(155) DEFAULT NULL,
  `descripcion_en` char(155) DEFAULT NULL,
  `url` char(155) DEFAULT NULL,
  `url_tn` char(155) DEFAULT NULL,
  `orden` tinyint(4) NOT NULL DEFAULT '0',
  `es_fijo` tinyint(4) NOT NULL DEFAULT '0',
  `es_foto` tinyint(4) NOT NULL DEFAULT '0',
  `es_temp` tinyint(4) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.gen_archivo: ~4 rows (aproximadamente)
DELETE FROM `gen_archivo`;
/*!40000 ALTER TABLE `gen_archivo` DISABLE KEYS */;
INSERT INTO `gen_archivo` (`id`, `usuario_id`, `banner_id`, `clave`, `nombre`, `nombre_en`, `descripcion`, `descripcion_en`, `url`, `url_tn`, `orden`, `es_fijo`, `es_foto`, `es_temp`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 0, 9, '', 'WhatsApp Image 2022-10-14 at 12.36.58 PM', NULL, NULL, NULL, '/media/temp/20221026104005.k6x.jpeg', NULL, 1, 0, 1, 1, 1, '2022-10-26 10:40:05', '2022-10-26 10:40:06', NULL),
	(2, 1007, 0, 'FOTO_VISITA', 'Screenshot 2022-10-17 at 11-33-42 Farmacias Bazar', NULL, NULL, NULL, '/media/temp/20221026110000.gj2.png', NULL, 1, 0, 1, 1, 1, '2022-10-26 11:00:00', '2022-10-26 11:00:48', '2022-10-26 11:00:48'),
	(3, 0, 8, '', 'name es', 'name en', 'desc es', 'desc en', '/media/temp/20221026111754.gz9.jpg', NULL, 1, 0, 1, 1, 1, '2022-10-26 11:17:54', '2022-11-28 12:56:05', NULL),
	(4, 0, 0, NULL, 'WESE', NULL, NULL, NULL, '/media/temp/20221128171540.rbb.jpg', NULL, 0, 0, 1, 1, 1, '2022-11-28 17:15:40', '2022-11-28 17:15:40', NULL);
/*!40000 ALTER TABLE `gen_archivo` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.gen_categoria
DROP TABLE IF EXISTS `gen_categoria`;
CREATE TABLE IF NOT EXISTS `gen_categoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpadre` int(11) NOT NULL DEFAULT '0',
  `tabla` char(155) DEFAULT NULL,
  `clave` char(155) DEFAULT NULL,
  `nombre` char(155) DEFAULT NULL,
  `descripcion` char(155) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.gen_categoria: ~0 rows (aproximadamente)
DELETE FROM `gen_categoria`;
/*!40000 ALTER TABLE `gen_categoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `gen_categoria` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.spp_producto
DROP TABLE IF EXISTS `spp_producto`;
CREATE TABLE IF NOT EXISTS `spp_producto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipovisa_id` int(11) NOT NULL DEFAULT '0',
  `clave` char(155) CHARACTER SET utf8 DEFAULT NULL,
  `num_personas` int(11) NOT NULL DEFAULT '0',
  `precio` decimal(20,2) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tipovisa_id` (`tipovisa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla tramitem_dev.spp_producto: ~2 rows (aproximadamente)
DELETE FROM `spp_producto`;
/*!40000 ALTER TABLE `spp_producto` DISABLE KEYS */;
INSERT INTO `spp_producto` (`id`, `tipovisa_id`, `clave`, `num_personas`, `precio`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 1, NULL, 1, 1000.00, 1, '2022-10-19 10:16:48', NULL, NULL, 0),
	(2, 1, NULL, 2, 1800.00, 1, '2022-10-19 10:16:48', NULL, NULL, 0);
/*!40000 ALTER TABLE `spp_producto` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.spp_servicio
DROP TABLE IF EXISTS `spp_servicio`;
CREATE TABLE IF NOT EXISTS `spp_servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` char(155) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre_en` char(155) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descripcion` text CHARACTER SET utf8,
  `descripcion_en` text COLLATE utf8_spanish_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla tramitem_dev.spp_servicio: ~6 rows (aproximadamente)
DELETE FROM `spp_servicio`;
/*!40000 ALTER TABLE `spp_servicio` DISABLE KEYS */;
INSERT INTO `spp_servicio` (`id`, `nombre`, `nombre_en`, `descripcion`, `descripcion_en`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 'DESTINO', NULL, '<p>M&eacute;xico es el cuarto pa&iacute;s de Am&eacute;rica Latina con el mayor n&uacute;mero de accesos al mundo sin visa, sin embargo, a&uacute;n hay muchos pa&iacute;ses donde es solicitado alg&uacute;n tipo de documento para ingresar, nosotros lo asesoramos para estos tr&aacute;mites y le asistimos para saber qu&eacute; tipo de Visa es la que necesita de acuerdo al prop&oacute;sito de su viaje.</p>', NULL, 1, '2022-10-10 17:10:04', '2022-10-26 11:06:46', NULL, 1001),
	(2, 'ANÁLISIS DEL PERFIL', NULL, '<p>El an&aacute;lisis del perfil se realiza a trav&eacute;s de un cuestionario, con la finalidad de brindarle una correcta asesor&iacute;a, as&iacute; como un panorama claro respecto al cumplimiento de los requisitos por parte de las distintas embajadas.</p>', NULL, 1, '2022-10-10 17:38:08', '2022-10-26 11:41:42', NULL, 1001),
	(3, 'ASISTENCIA', NULL, '<p>Lo asistiremos en la realizaci&oacute;n de los tr&aacute;mites necesarios para cada visado, de esta manera podemos garantizar el correcto llenado de formatos, registros y solicitudes por parte de las autoridades consulares y migratorias.</p>', NULL, 0, '2022-10-10 17:41:16', '2022-10-26 11:03:18', NULL, 1001),
	(4, 'ASESORÍA', NULL, '<p>Nuestra asesor&iacute;a se enfoca en las necesidades particulares de cada cliente, el modelo de servicio es personalizado, un asesor le ser&aacute; asignado para llevar sus tr&aacute;mites de principio a fin y los guiar&aacute; a trav&eacute;s del proceso de visado.</p>', NULL, 0, '2022-10-10 17:49:19', '2022-10-26 11:04:47', NULL, 1001),
	(5, 'GRUPOS', NULL, '<p>Puede realizar un visado grupal a partir de 3 personas o m&aacute;s viajando juntos con un mismo prop&oacute;sito de viaje, grupos deportivos, culturales, compa&ntilde;eros de trabajo que van a entrenamiento o conferencias, estudiantes en programas de intercambio culturales, &nbsp;miembros de un grupo con petici&oacute;n de trabajo otorgada, m&uacute;sicos.</p>', NULL, 0, '2022-10-10 17:49:36', '2022-10-26 11:05:01', NULL, 1001),
	(6, 'EMPRESAS', NULL, '<p>Actualmente las empresas necesitan una opci&oacute;n r&aacute;pida y confiable para el tr&aacute;mite de visas de sus ejecutivos, los congresos, las capacitaciones y los negocios alrededor del mundo son una necesidad en aquellos negocios que buscan consolidarse a nivel internacional.</p>', NULL, 1, '2022-10-10 17:49:53', '2022-10-26 11:06:58', NULL, 1001);
/*!40000 ALTER TABLE `spp_servicio` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.spp_tipovisa
DROP TABLE IF EXISTS `spp_tipovisa`;
CREATE TABLE IF NOT EXISTS `spp_tipovisa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` char(155) CHARACTER SET utf8 DEFAULT NULL,
  `nombre` char(155) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre_en` char(155) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  `descripcion_en` text COLLATE utf8_spanish_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla tramitem_dev.spp_tipovisa: ~5 rows (aproximadamente)
DELETE FROM `spp_tipovisa`;
/*!40000 ALTER TABLE `spp_tipovisa` DISABLE KEYS */;
INSERT INTO `spp_tipovisa` (`id`, `clave`, `nombre`, `nombre_en`, `descripcion`, `descripcion_en`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, NULL, 'Tramite Visa Usa123', NULL, '<p>demowdwqEDEER</p>', NULL, 1, '2022-10-19 11:38:21', '2022-10-26 11:16:07', NULL, 1001),
	(2, NULL, 'Renovación', NULL, '<p>wefwearffefawe</p>', NULL, 1, '2022-10-19 12:20:41', '2022-10-19 12:21:03', NULL, 1001),
	(3, NULL, 'hols', NULL, '<p>hi</p>\r\n\r\n<p>&nbsp;</p>', NULL, 1, '2022-10-26 10:44:39', '2022-10-26 11:16:13', NULL, 1001),
	(4, NULL, 'fdgs', NULL, '<p>gggfd</p>', NULL, 1, '2022-10-26 10:45:19', '2022-10-26 11:16:19', NULL, 1001),
	(5, NULL, '123123', NULL, '<p>1231231</p>', NULL, 1, '2022-10-26 11:16:29', '2022-10-26 11:17:05', NULL, 1001);
/*!40000 ALTER TABLE `spp_tipovisa` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.web_banner
DROP TABLE IF EXISTS `web_banner`;
CREATE TABLE IF NOT EXISTS `web_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` char(155) DEFAULT NULL,
  `nombre` char(155) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.web_banner: ~4 rows (aproximadamente)
DELETE FROM `web_banner`;
/*!40000 ALTER TABLE `web_banner` DISABLE KEYS */;
INSERT INTO `web_banner` (`id`, `clave`, `nombre`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(7, 'hola', 'fgj', 1, '2022-10-26 10:34:30', '2022-10-26 11:32:13', NULL, 0),
	(8, 'BANNER', 'BNR_INICIOjrj', 1, '2022-10-26 10:38:21', '2022-11-28 12:56:05', NULL, 1001),
	(9, 'asdfsf', 'sdafaf', 1, '2022-10-26 10:38:45', '2022-10-26 10:41:39', NULL, 1001),
	(10, 'mundo', 'rtre', 1, '2022-10-26 10:39:45', '2022-10-26 11:32:26', NULL, 1001);
/*!40000 ALTER TABLE `web_banner` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.web_faq
DROP TABLE IF EXISTS `web_faq`;
CREATE TABLE IF NOT EXISTS `web_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL DEFAULT '0',
  `clave` char(155) DEFAULT NULL,
  `descripcion` char(155) DEFAULT NULL,
  `respuesta` text,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.web_faq: ~0 rows (aproximadamente)
DELETE FROM `web_faq`;
/*!40000 ALTER TABLE `web_faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_faq` ENABLE KEYS */;

-- Volcando estructura para tabla tramitem_dev.web_pagina
DROP TABLE IF EXISTS `web_pagina`;
CREATE TABLE IF NOT EXISTS `web_pagina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpadre` int(11) NOT NULL DEFAULT '0',
  `clave` char(155) DEFAULT NULL,
  `nombre` char(155) DEFAULT NULL,
  `descripcion_corta` char(155) DEFAULT NULL,
  `descripcion` text,
  `url` char(155) DEFAULT NULL,
  `orden` int(11) NOT NULL DEFAULT '1',
  `es_fijo` tinyint(4) NOT NULL DEFAULT '0',
  `es_visible` tinyint(4) NOT NULL DEFAULT '1',
  `es_menu` tinyint(4) NOT NULL DEFAULT '1',
  `mostrar_suscribete` tinyint(4) NOT NULL DEFAULT '0',
  `abrir_otra_ventana` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`),
  KEY `idpadre` (`idpadre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla tramitem_dev.web_pagina: ~6 rows (aproximadamente)
DELETE FROM `web_pagina`;
/*!40000 ALTER TABLE `web_pagina` DISABLE KEYS */;
INSERT INTO `web_pagina` (`id`, `idpadre`, `clave`, `nombre`, `descripcion_corta`, `descripcion`, `url`, `orden`, `es_fijo`, `es_visible`, `es_menu`, `mostrar_suscribete`, `abrir_otra_ventana`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_by`) VALUES
	(1, 0, 'INICIO', 'Inicio', NULL, NULL, '/', 1, 1, 1, 1, 0, 0, 1, '2022-09-07 12:41:47', '2022-10-26 10:54:12', NULL, 0),
	(2, 0, 'TIPOS_VISAS', 'Tipos de Visas', NULL, NULL, '/tiposvisas', 2, 1, 1, 1, 0, 0, 1, '2022-09-07 12:41:47', '2022-10-19 11:24:42', NULL, 0),
	(3, 0, 'SERVICIOS', 'Servicios', NULL, NULL, '/servicios', 3, 1, 1, 1, 0, 0, 1, '2022-09-07 12:41:47', '2022-09-11 11:44:58', NULL, 0),
	(4, 0, 'TIENDA', 'Tienda', NULL, NULL, '/productos', 4, 1, 1, 1, 0, 0, 1, '2022-09-07 12:41:47', '2022-10-26 10:53:56', NULL, 0),
	(5, 0, 'CONTACTOo', 'Contacto', NULL, NULL, '/contacto', 7, 1, 1, 1, 0, 0, 1, '2022-09-07 12:41:47', '2022-10-26 10:54:03', NULL, 0),
	(6, 0, 'NOSOTROS', 'Nosotros', NULL, NULL, '/nosotros', 1, 0, 1, 1, 0, 0, 1, '2022-09-10 16:41:28', '2022-10-10 18:03:21', NULL, 0);
/*!40000 ALTER TABLE `web_pagina` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
